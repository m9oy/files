import {world,system} from "@minecraft/server";

const player_position = new Map();

system.runInterval(()  =>{
    for (const player of world.getPlayers()){

        const current_position = player.location;

        const old_position = player_position.get(player.id)

        if (!old_position){
            player_position.set(player.id,current_position);
            continue;
        }

        const dx= current_position.x-old_position.x;
        const dz= current_position.z-old_position.z;

        const distance = Math.sqrt(dx*dx+dz*dz);

        if (distance>1){
            if (player.isSprinting){
                player.addExperience(100);
            } else {
                player.addExperience(20);
            }
            }
         player_position.set(player.id,current_position);
        }
    },5)